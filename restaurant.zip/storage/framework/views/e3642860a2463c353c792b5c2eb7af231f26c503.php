<?php
/**
 * Created by PhpStorm.
 * User: Kawshar
 * Date: 7/13/2018
 * Time: 10:03 AM
 */?>
;
<?php $__env->startSection('title','Reservation'); ?>
<?php $__env->startSection('page_title'); ?>
    Manage Reservation
<?php $__env->stopSection(); ?>

<?php $__env->startSection('page_main_title'); ?>
    Reservation
<?php $__env->stopSection(); ?>


<?php $__env->startSection('content'); ?>
    <!-- Example DataTables Card-->
    <div class="row">
        <div class="col-md-12">
            <div class="card-box">
                <?php echo $__env->make('admin.layouts.includes.message', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                <div class="card">
                    <div class="card-header">
                    </div>
                    <div class="card-body">
                        <div class="table-responsive">
                            <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
                                <thead>
                                <tr>
                                    <th>No</th>
                                    <th>Name</th>
                                    <th>Phone</th>
                                    <th>E-mail</th>
                                    <th>Message</th>
                                    <th>Time and Date</th>
                                    <th>Status Status </th>
                                    <th>Action</th>

                                </tr>
                                </thead>
                                <tbody>

                                <?php $__currentLoopData = $reservations; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$reservation): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td><?php echo e($key + 1); ?></td>
                                        <td><?php echo e($reservation->name); ?></td>
                                        <td><?php echo e($reservation->phone); ?></td>
                                        <td><?php echo e($reservation->email); ?></td>
                                        <td><?php echo e($reservation->message); ?></td>
                                        <td><?php echo e($reservation->time_and_date); ?></td>
                                        <td>
                                            <?php if($reservation->status==1): ?>
                                                <label class="btn btn-success">Confirm</label>
                                            <?php else: ?>
                                                <label class="btn btn-danger">Pending</label>
                                            <?php endif; ?>

                                        </td>
                                        <td>





                                            <?php if($reservation->status==1): ?>

                                                <button type="button" class="btn btn-sm btn-success" ><i class="fa fa-check"></i> </button>
                                            <?php else: ?>
                                                <form action="<?php echo e(route('reservations.status',$reservation->id)); ?>" method="post" id="resrvation-<?php echo e($reservation->id); ?>" >
                                                    <?php echo csrf_field(); ?>
                                                    <?php echo method_field('POST'); ?>
                                                </form>

                                                <button type="button" class="btn btn-sm btn-danger"  onclick="if (confirm('Are you sure verify this request by phone?????')){

                                                        event.preventDefault();
                                                        document.getElementById('resrvation-<?php echo e($reservation->id); ?>').submit();
                                                        } "><i class="fa fa-check"></i> </button>
                                            <?php endif; ?>

                                                <form action="<?php echo e(route('reservations.delete',$reservation->id)); ?>"  method="post" id="formDelete-<?php echo e($reservation->id); ?>" >
                                                    <?php echo csrf_field(); ?>
                                                    <?php echo method_field('DELETE'); ?>
                                                </form>
                                                <button type="button" class="btn btn-sm btn-danger" title="Delete" onclick="if (confirm('Are you sure delete this reservation???')){

                                                        event.preventDefault();
                                                        document.getElementById('formDelete-<?php echo e($reservation->id); ?>').submit();
                                                        } "><i class="fa fa-trash"></i> </button>
                                                <a  href="<?php echo e(route('reservations.show',$reservation->id)); ?>" class="btn btn-sm btn-info" title="Details"><i class="fa fa-info-circle"></i></a>














                                        </td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                </tbody>
                            </table>
                        </div>
                    </div>
                    <div class="card-footer small text-muted">Updated yesterday at 11:59 PM</div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>