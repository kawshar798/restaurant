<?php $__env->startSection('title'); ?>
    Dashboard
    <?php $__env->stopSection(); ?>
<?php $__env->startSection('page_title'); ?>
    Dashboard
<?php $__env->stopSection(); ?>

<?php $__env->startSection('page_main_title'); ?>
    Dashboard
<?php $__env->stopSection(); ?>


<?php $__env->startSection('content'); ?>

    <div class="row">
        <div class="col-lg-2 col-md-4 col-sm-6">
            <div class="card-box widget-box-one">
                <i class="mdi mdi-chart-areaspline widget-one-icon"></i>
                <div class="wigdet-one-content">
                    <p class="m-0 text-uppercase font-600 font-secondary text-overflow" title="Statistics">Reservation </p>
                    <span class="text-danger">Pending</span>
                    <h2><?php echo e($reservationsPen->count()); ?></h2>
                </div>
            </div>
        </div><!-- end col -->

        <div class="col-lg-2 col-md-4 col-sm-6">
            <div class="card-box widget-box-one">
                <i class="mdi mdi-account-convert widget-one-icon"></i>
                <div class="wigdet-one-content">
                    <p class="m-0 text-uppercase font-600 font-secondary text-overflow" title="User Today">Reservation</p>
                    <span class="text-success">Confirm</span>
                    <h2><?php echo e($reservationsCon->count()); ?></h2>
                </div>
            </div>
        </div><!-- end col -->
        <div class="col-lg-2 col-md-4 col-sm-6">
            <div class="card-box widget-box-one">
                <i class="mdi mdi-layers widget-one-icon"></i>
                <div class="wigdet-one-content">
                    <p class="m-0 text-uppercase font-600 font-secondary text-overflow" title="User This Month">Total Category</p>
                    <h2><?php echo e($category->count()); ?></h2>
                </div>
            </div>
        </div><!-- end col -->

        <div class="col-lg-2 col-md-4 col-sm-6">
            <div class="card-box widget-box-one">
                <i class="mdi mdi-layers widget-one-icon"></i>
                <div class="wigdet-one-content">
                    <p class="m-0 text-uppercase font-600 font-secondary text-overflow" title="User This Month">Total Items</p>
                    <h2><?php echo e($item->count()); ?></h2>
                </div>
            </div>
        </div><!-- end col -->


        <div class="col-lg-2 col-md-4 col-sm-6">
            <div class="card-box widget-box-one">
                <i class="mdi mdi-av-timer widget-one-icon"></i>
                <div class="wigdet-one-content">
                    <p class="m-0 text-uppercase font-600 font-secondary text-overflow" title="Request Per Minute">Chef</p>
                    <h2><?php echo e($chef->count()); ?></h2>

                </div>
            </div>
        </div><!-- end col -->

    </div>
    <div class="row">
        <div class="col-lg-12">
            <div class="card-box">
                <h4 class="header-title m-t-0 m-b-30">Recent Reservation </h4>

                <div class="table-responsive">
                    <table class="table table table-hover m-0">
                        <thead>
                        <tr>
                            <th>No</th>
                            <th>User Name</th>
                            <th>Phone</th>
                            <th>E-mail</th>
                            <th>Message</th>
                            <th>Date</th>
                            <th>Status</th>
                        </tr>
                        </thead>
                        <tbody>
                        <?php $__currentLoopData = $reservations; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$reservation): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>

                                <td><?php echo e($key+1); ?></td>
                                <td><?php echo e($reservation->name); ?></td>
                                <td><?php echo e($reservation->phone); ?></td>
                                <td><?php echo e($reservation->email); ?></td>
                                <td><?php echo e($reservation->message); ?></td>
                                <td><?php echo e($reservation->time_and_date); ?></td>
                                <td>
                                    <?php if($reservation->status==1): ?>
                                        <label class="btn btn-success">Confirm</label>
                                    <?php else: ?>
                                        <label class="btn btn-danger">Pending</label>
                                    <?php endif; ?>

                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>

                </div> <!-- table-responsive -->
            </div> <!-- end card -->
        </div>
        <!-- end col -->
    </div>
    <!-- end row -->


<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layouts.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>