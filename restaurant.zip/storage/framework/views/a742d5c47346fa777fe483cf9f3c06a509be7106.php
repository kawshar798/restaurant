<?php
/**
 * Created by PhpStorm.
 * User: Kawshar
 * Date: 7/12/2018
 * Time: 8:34 AM
 */?>
<?php if(session()->has('msg')): ?>
    <div class="alert alert-success">
        <?php echo e(session()->get('msg')); ?>

    </div>

<?php endif; ?>
