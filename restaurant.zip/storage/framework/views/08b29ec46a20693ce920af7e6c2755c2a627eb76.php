<?php
/**
 * Created by PhpStorm.
 * User: Kawshar
 * Date: 7/10/2018
 * Time: 11:07 AM
 */?>


<?php $__env->startSection('page_title'); ?>
   Item Details
<?php $__env->stopSection(); ?>
<?php $__env->startSection('page_main_title'); ?>
    Item
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="col-md-12">
            <div class="card-box">
                <?php echo $__env->make('admin.layouts.includes.message', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                <table class="table ">
                    <tr>
                        <td>Name</td>
                        <td><?php echo e($item->name); ?></td>
                    </tr>
                    <tr>
                        <td>Category name</td>
                        <td><?php echo e($item->category->name); ?></td>
                    </tr>
                    <tr>
                        <td>Category name</td>
                        <td><?php echo e($item->description); ?></td>
                    </tr> <tr>
                        <td>Category name</td>
                        <td><?php echo e($item->price); ?></td>
                    </tr>
                    <tr>
                        <td>Image</td>
                        <td>
                            <img src="<?php echo e(url('uploads/item/'.$item->image)); ?>" width="100px">
                        </td>
                    </tr>
                    <tr>
                        <td>Publication Status</td>
                        <td>
                            <?php if($item->publication_status==1): ?>
                                Published
                            <?php else: ?>
                                unpublished
                            <?php endif; ?>

                        </td>
                    </tr>


                </table>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>



<?php echo $__env->make('admin.layouts.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>