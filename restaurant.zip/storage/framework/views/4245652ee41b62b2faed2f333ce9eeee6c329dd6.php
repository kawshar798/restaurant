<?php
/**
 * Created by PhpStorm.
 * User: Kawshar
 * Date: 7/10/2018
 * Time: 11:07 AM
 */?>


<?php $__env->startSection('page_title'); ?>
    Item Details
<?php $__env->stopSection(); ?>
<?php $__env->startSection('page_main_title'); ?>
    Item
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="col-md-12">
            <div class="card-box">
                <table class="table ">
                    <tr>
                        <td>Name</td>
                        <td><?php echo e($contact->name); ?></td>
                    </tr>
                    <tr>
                        <td>E-mail</td>
                        <td><?php echo e($contact->email); ?></td>
                    </tr>
                    <tr>
                        <td>Subject</td>
                        <td><?php echo e($contact->subject); ?></td>
                    </tr>
                     <tr>
                        <td>Message</td>
                        <td><?php echo e($contact->message); ?></td>
                    </tr>
                    <tr>
                        <td>Date and Time</td>
                        <td>
                            <?php echo e($contact->created_at); ?>

                        </td>
                    </tr>


                </table>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>



<?php echo $__env->make('admin.layouts.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>