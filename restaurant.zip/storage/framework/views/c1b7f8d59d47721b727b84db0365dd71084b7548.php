<?php
/**
 * Created by PhpStorm.
 * User: Kawshar
 * Date: 7/10/2018
 * Time: 11:07 AM
 */?>


<?php $__env->startSection('page_title'); ?>
    Sliders Manage
<?php $__env->stopSection(); ?>
<?php $__env->startSection('page_main_title'); ?>
    Slider
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="col-md-12">
            <div class="card-box">
                <?php echo $__env->make('admin.layouts.includes.message', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                <table class="table ">
                    <tr>
                        <td>Title</td>
                        <td><?php echo e($slider->title); ?></td>
                    </tr>
                    <tr>
                        <td>Sub Title</td>
                        <td><?php echo e($slider->sub_title); ?></td>
                    </tr>
                    <tr>
                        <td>Image</td>
                        <td>
                            <img src="<?php echo e(url('uploads/sliders/'.$slider->image)); ?>" width="100px">
                            </td>
                    </tr>
                    <tr>
                        <td>Publication Status</td>
                        <td>
                            <?php if($slider->publication_status==1): ?>
                                Published
                                <?php else: ?>
                                unpublished
                                <?php endif; ?>

                            </td>
                    </tr>


                </table>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>



<?php echo $__env->make('admin.layouts.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>