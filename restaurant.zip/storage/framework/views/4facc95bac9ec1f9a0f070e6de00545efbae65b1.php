<?php
/**
 * Created by PhpStorm.
 * User: Kawshar
 * Date: 7/14/2018
 * Time: 4:25 PM
 */?>
<div class="inner-page-banner-area">
    <div class="container">
        <div class="pagination-area">
            <h2><?php echo $__env->yieldContent('banner_title'); ?></h2>
            <ul>
                <li><a href="/">Home -</a> /</li>
                <li><?php echo $__env->yieldContent('page_title'); ?></li>
            </ul>
        </div>
    </div>
</div>
