<?php
/**
 * Created by PhpStorm.
 * User: Kawshar
 * Date: 7/10/2018
 * Time: 11:07 AM
 */?>


<?php $__env->startSection('page_title'); ?>
    Add  Time and Day
<?php $__env->stopSection(); ?>
<?php $__env->startSection('page_main_title'); ?>
    Time Management
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="col-sm-12">
            <div class="card-box">
                <div class="row">
                    <div class="col-md-10">
                        <form class="form-horizontal" method="post" action="<?php echo e(route('sponsors.update',$sponsor->id)); ?>" enctype="multipart/form-data">
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('PUT'); ?>

                            <div class="form-group <?php echo e($errors->has('name') ? 'has-error' : ''); ?>">
                                <label class="col-md-2 control-label">Name</label>
                                <div class="col-md-10">

                                    <input type="text" name="name" class="form-control"  value="<?php echo e($sponsor->name); ?>">
                                    <span class="text-danger"><?php echo e($errors->has('name')?$errors->first('name') : ''); ?></span>

                                </div>
                            </div>
                            <div class="form-group <?php echo e($errors->has('image') ? 'has->error' : ''); ?>">
                                <label class="col-md-2 control-label">Sponsor Brand   Image</label>
                                <div class="col-md-10">
                                    <input type="file" name="image" class="form-control">
                                    <span class="text-danger"><?php echo e($errors->has('image')?$errors->first('image') : ''); ?></span>
                                </div>
                            </div>

                            <div class="form-group">
                                <button class="btn btn-success btn-lg col-md-offset-2" type="submit">Add Item</button>
                            </div>
                        </form>
                    </div>
                </div>

            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>