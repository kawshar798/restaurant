<?php
/**
 * Created by PhpStorm.
 * User: Kawshar
 * Date: 7/10/2018
 * Time: 11:07 AM
 */?>


<?php $__env->startSection('title','Slider'); ?>
<?php $__env->startSection('page_title'); ?>
    Sliders Manage
    <?php $__env->stopSection(); ?>
<?php $__env->startSection('page_main_title'); ?>
    Slider
    <?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="col-md-12">
            <div class="card-box">
                <?php echo $__env->make('admin.layouts.includes.message', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                <table class="table ">
                    <thead>
                    <tr>
                        <td>No</td>
                        <td>Title</td>
                        <td>Sub Title</td>
                        <td>Image</td>
                        <td>Publication Status</td>
                        <td>action</td>
                    </tr>
                    </thead>
                    <tbody>
                    <?php $__currentLoopData = $sliders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$slider): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($key+1); ?></td>
                        <td><?php echo e($slider->title); ?></td>
                        <td><?php echo e($slider->sub_title); ?></td>
                        <td>
                        <img src="<?php echo e(url('uploads/sliders/'.$slider->image)); ?>" width="30px">
                        </td>
                        <td>
                            <?php if($slider->publication_status==1): ?>
                                Published

                            <?php else: ?>
                                Unpublished
                            <?php endif; ?>

                        </td>
                        <td>

                            <form action="<?php echo e(route('sliders.destroy',$slider->id)); ?>" method="post" id="sliderDelete-<?php echo e($slider->id); ?>">
                                <?php echo csrf_field(); ?>
                                <?php echo method_field('DELETE'); ?>

                            </form>

                            <button type="button" class="btn btn-sm btn-danger" title="Delete" onclick="if (confirm('Are you sure delete this slider???')){

                                    event.preventDefault();
                                    document.getElementById('sliderDelete-<?php echo e($slider->id); ?>').submit();
                                    } "><i class="fa fa-trash"></i></button>

                            <?php if($slider->publication_status==1): ?>
                                <a  href="<?php echo e(route('sliders.unpublished',$slider->id)); ?>" class="btn btn-sm btn-primary" title="Unpublished"><i class="fa fa-arrow-circle-up"></i></a>
                                <?php else: ?>
                                <a  href="<?php echo e(route('sliders.published',$slider->id)); ?>" class="btn btn-sm btn-warning" title="Published"><i class="fa fa-arrow-circle-down"></i></a>

                            <?php endif; ?>
                            <a  href="<?php echo e(route('sliders.edit',$slider->id)); ?>" class="btn btn-sm btn-success" title="Edit"><i class="fa fa-edit"></i></a>
                            <a  href="<?php echo e(route('sliders.show',$slider->id)); ?>" class="btn btn-sm btn-info" title="Details"><i class="fa fa-info"></i></a>
                        </td>
                    </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>



<?php echo $__env->make('admin.layouts.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>