<?php
/**
 * Created by PhpStorm.
 * User: Kawshar
 * Date: 7/15/2018
 * Time: 4:49 PM
 */?>


<?php $__env->startSection('title'); ?>
   About US
<?php $__env->stopSection(); ?>
<?php $__env->startSection('banner_title'); ?>
    About US
<?php $__env->stopSection(); ?>
<?php $__env->startSection('page_title'); ?>
    About
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <?php echo $__env->make('front-end.layouts.includes.banner_area', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    <!-- Contact Us Page Area Start Here -->
    <?php $__currentLoopData = $aboutus; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $about): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="about-page2-area section-space">
            <div class="container">
                <div class="row no-gutters about-page2-inner">
                    <div class="col-lg-6 col-md-6 col-sm-6 col-xs-12">
                        <div class="about-page2-content">
                            <h2><?php echo e($about->title); ?></h2>
                            <p><?php echo e($about->description); ?></p>
                        </div>
                    </div>
                    <div class="col-lg-6 col-md-6 col-sm-6 col-xs-12">
                        <div class="about-page2-img-holder">
                            <img src="<?php echo e(url('uploads/about/'.$about->image)); ?>" class="img-responsive" alt="about-banner">
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    <!-- Brand Area Start Here -->
    <div class="brand-area">
        <img class="img-responsive section-back" src="img/brand/back-logo.png" alt="back-logo">
        <div class="container">
            <div class="rc-carousel"
                 data-loop="true"
                 data-items="6"
                 data-margin="15"
                 data-autoplay="true"
                 data-autoplay-timeout="10000"
                 data-smart-speed="2000"
                 data-dots="false"
                 data-nav="true"
                 data-nav-speed="false"
                 data-r-x-small="2"
                 data-r-x-small-nav="false"
                 data-r-x-small-dots="true"
                 data-r-x-medium="3"
                 data-r-x-medium-nav="false"
                 data-r-x-medium-dots="true"
                 data-r-small="4"
                 data-r-small-nav="true"
                 data-r-small-dots="false"
                 data-r-medium="6"
                 data-r-medium-nav="true"
                 data-r-medium-dots="false">
                <?php $__currentLoopData = $sponsors; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sponsor): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="brand-area-box">
                        <a href="<?php echo e($sponsor->link); ?>"><img src="<?php echo e(url('uploads/brands/'.$sponsor->image)); ?>" alt="brand"></a>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </div>
    </div>

    <!-- Contact Us Page Area End Here -->
<?php $__env->stopSection(); ?>
<?php echo $__env->make('front-end.layouts.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>