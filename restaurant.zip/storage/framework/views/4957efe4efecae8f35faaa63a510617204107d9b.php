<?php
/**
 * Created by PhpStorm.
 * User: Kawshar
 * Date: 7/14/2018
 * Time: 4:24 PM
 */?>
<div class="slider1-area">
    <div class="bend niceties preview-1">
        <div id="ensign-nivoslider-3" class="slides">
            <?php $__currentLoopData = $sliders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $slider): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <img src="<?php echo e(url('uploads/sliders/'.$slider->image)); ?>" alt="slider" title="#slider-direction-<?php echo e($slider->id); ?>"/>

            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

        </div>
        <?php $__currentLoopData = $sliders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $slider): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div id="slider-direction-<?php echo e($slider->id); ?>" class="t-cn slider-direction">
                <div class="slider-content s-tb slide-<?php echo e($slider->id); ?>">
                    <div class="title-container s-tb-c">
                        <h1 class="title1"><?php echo e($slider->title); ?></h1>
                        <p><?php echo e($slider->sub_title); ?></p>
                        <div class="slider-btn-area">

                        </div>
                    </div>
                </div>
            </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


    </div>
</div>
