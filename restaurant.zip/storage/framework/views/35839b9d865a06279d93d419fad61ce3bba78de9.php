<?php
/**
 * Created by PhpStorm.
 * User: Kawshar
 * Date: 7/10/2018
 * Time: 11:07 AM
 */?>


<?php $__env->startSection('page_title'); ?>
    Edit Logo and Social
<?php $__env->stopSection(); ?>
<?php $__env->startSection('page_main_title'); ?>
    Logo and Social
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="col-sm-12">
            <div class="card-box">
                <div class="row">
                    <div class="col-md-10">
                        <form class="form-horizontal" method="post" action="<?php echo e(route('setting.update',$setting->id)); ?>" enctype="multipart/form-data">
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('PUT'); ?>
                            <div class="form-group <?php echo e($errors->has('facebook') ? 'has-error' : ''); ?>">
                                <label class="col-md-2 control-label">facebook</label>
                                <div class="col-md-10">
                                    <input type="text" name="facebook" class="form-control" value="<?php echo e($setting->facebook); ?>">
                                    <span class="text-danger"><?php echo e($errors->has('facebook')?$errors->first('facebook') : ''); ?></span>

                                </div>
                            </div>
                            <div class="form-group <?php echo e($errors->has('linkedin') ? 'has-error' : ''); ?>">
                                <label class="col-md-2 control-label">Linkedin</label>
                                <div class="col-md-10">
                                    <input type="text" name="linkedin" class="form-control"  value="<?php echo e($setting->linkedin); ?>">
                                    <span class="text-danger"><?php echo e($errors->has('linkedin')?$errors->first('linkedin') : ''); ?></span>

                                </div>
                            </div>
                            <div class="form-group <?php echo e($errors->has('twitter') ? 'has-error' : ''); ?>">
                                <label class="col-md-2 control-label">Twitter</label>
                                <div class="col-md-10">
                                    <input type="text" name="twitter" class="form-control"  value="<?php echo e($setting->twitter); ?>">
                                    <span class="text-danger"><?php echo e($errors->has('twitter')?$errors->first('twitter') : ''); ?></span>

                                </div>
                            </div>
                            <div class="form-group <?php echo e($errors->has('instagram') ? 'has-error' : ''); ?>">
                                <label class="col-md-2 control-label">Instagram</label>
                                <div class="col-md-10">
                                    <input type="text" name="instagram" class="form-control" value="<?php echo e($setting->instagram); ?>">
                                    <span class="text-danger"><?php echo e($errors->has('instagram')?$errors->first('instagram') : ''); ?></span>

                                </div>
                            </div>


                            <div class="form-group <?php echo e($errors->has('logo') ? 'has-error' : ''); ?>">
                                <label class="col-md-2 control-label">Logo</label>
                                <div class="col-md-10">
                                    <input type="file" name="logo" class="form-control" placeholder="Enter logo">
                                    <span class="text-danger"><?php echo e($errors->has('logo')?$errors->first('logo') : ''); ?></span>

                                </div>
                            </div>
                            <div class="form-group">
                                <button class="btn btn-success btn-lg col-md-offset-2" type="submit">Submit</button>
                            </div>
                        </form>
                    </div>
                </div>

            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>