<?php
/**
 * Created by PhpStorm.
 * User: Kawshar
 * Date: 7/13/2018
 * Time: 10:03 AM
 */?>
;
<?php $__env->startSection('page_title'); ?>
    Manage Category
<?php $__env->stopSection(); ?>

<?php $__env->startSection('page_main_title'); ?>
    Category
<?php $__env->stopSection(); ?>


<?php $__env->startSection('content'); ?>
    <!-- Example DataTables Card-->
    <div class="row">
        <div class="col-md-12">
            <div class="card-box">
                <?php echo $__env->make('admin.layouts.includes.message', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                <div class="card">
                    <div class="card-header">
                    </div>
                    <div class="card-body">
                        <a href="<?php echo e(route('categories.edit',$category->id)); ?>" class="btn btn-success">Category Edit</a>
                        <div class="table-responsive">
                            <table class="table" id="dataTable" width="100%" cellspacing="0">
                              <tr>
                                  <td>Id</td>
                                  <td><?php echo e($category->id); ?></td>
                              </tr>
                                <tr>
                                    <td>Name</td>
                                    <td><?php echo e($category->name); ?></td>
                                </tr>
                                <tr>
                                    <td>slug</td>
                                    <td><?php echo e($category->slug); ?></td>
                                </tr>
                                <tr>
                                    <td>Publication Status</td>
                                    <td> <?php if($category->publication_status==1): ?>
                                             Published
                                             <?php else: ?>
                                             Unpublished
                                             <?php endif; ?>

                                    </td>
                                </tr>
                            </table>
                        </div>
                    </div>
                    <div class="card-footer small text-muted">Updated yesterday at 11:59 PM</div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>