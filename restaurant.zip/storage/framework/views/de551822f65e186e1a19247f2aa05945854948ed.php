<?php
/**
 * Created by PhpStorm.
 * User: Kawshar
 * Date: 7/10/2018
 * Time: 11:07 AM
 */?>


<?php $__env->startSection('page_title'); ?>
    Item Details
<?php $__env->stopSection(); ?>
<?php $__env->startSection('page_main_title'); ?>
    Item
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="col-md-12">
            <div class="card-box">
                <table class="table ">
                    <tr>
                        <td>Name</td>
                        <td><?php echo e($reservation->name); ?></td>
                    </tr>
                    <tr>
                        <td>E-mail</td>
                        <td><?php echo e($reservation->email); ?></td>
                    </tr>
                    <tr>
                        <td>Phone Number</td>
                        <td><?php echo e($reservation->phone); ?></td>
                    </tr> <tr>
                        <td>Message</td>
                        <td><?php echo e($reservation->message); ?></td>
                    </tr>
                    <tr>
                        <td>Date and Time</td>
                        <td>
                            <?php echo e($reservation->time_and_date); ?>

                        </td>
                    </tr>
                    <tr>
                        <td> Status</td>
                        <td>
                            <?php if($reservation->status==1): ?>
                                <label class="btn btn-success">Confirm</label>
                            <?php else: ?>
                                <label class="btn btn-danger">Pending</label>
                            <?php endif; ?>

                        </td>
                    </tr>


                </table>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>



<?php echo $__env->make('admin.layouts.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>