<?php
/**
 * Created by PhpStorm.
 * User: Kawshar
 * Date: 7/13/2018
 * Time: 10:03 AM
 */?>
;
<?php $__env->startSection('page_title'); ?>
    Add   Logo and Social
<?php $__env->stopSection(); ?>

<?php $__env->startSection('page_main_title'); ?>
    Logo and Social
<?php $__env->stopSection(); ?>


<?php $__env->startSection('content'); ?>
    <!-- Example DataTables Card-->
    <div class="row">
        <div class="col-md-12">
            <div class="card-box">
                <div class="card">
                    <div class="card-header">
                    </div>
                    <div class="card-body">
                        <div class="table-responsive">
                            <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
                                <thead>
                                <tr>
                                    <th>No</th>
                                    <th>Facebook</th>
                                    <th>Linkedin</th>
                                    <th>Twitter</th>
                                    <th>Instagram</th>
                                    <th>Logo</th>
                                    <th>Action</th>

                                </tr>
                                </thead>
                                <tbody>

                                <?php $__currentLoopData = $settings; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$setting): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td><?php echo e($key + 1); ?></td>
                                        <td><?php echo e($setting->facebook); ?></td>
                                        <td><?php echo e($setting->linkedin); ?></td>
                                        <td><?php echo e($setting->twitter); ?></td>
                                        <td><?php echo e($setting->instagram); ?></td>
                                        <td>
                                            <img src="<?php echo e(url('uploads/logo/'.$setting->logo)); ?>" width="30px">
                                        </td>
                                        <td>
                                            <form action="<?php echo e(route('setting.destroy',$setting->id)); ?>" method="post" id="sliderDelete-<?php echo e($setting->id); ?>">
                                                <?php echo csrf_field(); ?>
                                                <?php echo method_field('DELETE'); ?>

                                            </form>

                                            <button type="button" class="btn btn-sm btn-danger" title="Delete" onclick="if (confirm('Are you sure delete this Item???')){

                                                    event.preventDefault();
                                                    document.getElementById('sliderDelete-<?php echo e($setting->id); ?>').submit();
                                                    } "><i class="fa fa-trash"></i></button>
                                                <a  href="<?php echo e(route('setting.edit',$setting->id)); ?>" class="btn btn-sm btn-success" title="Edit"><i class="fa fa-edit"></i></a>
                                                <a  href="<?php echo e(route('setting.show',$setting->id)); ?>" class="btn btn-sm btn-info" title="Details"><i class="fa fa-info"></i></a>









                                        </td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>