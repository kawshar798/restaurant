<?php $__env->startSection('title'); ?>
    HOME
    <?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <!-- Slider Area Start Here -->
    <?php echo $__env->make('front-end.layouts.includes.slider', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    <!-- Slider Area End Here -->
    <!-- Special Dish Area Start Here -->
    <div class="special-dish-area">
        <div class="container">
            <h2 class="title">Our Latest Dishes </h2>
            <span class="subtitle-color">Let’s Discover Food</span>
            <div class="row">
                <div class="rc-carousel"
                     data-loop="true"
                     data-items="4"
                     data-margin="15"
                     data-autoplay="true"
                     data-autoplay-timeout="10000"
                     data-smart-speed="2000"
                     data-dots="false"
                     data-nav="true"
                     data-nav-speed="false"
                     data-r-x-small="1"
                     data-r-x-small-nav="false"
                     data-r-x-small-dots="true"
                     data-r-x-medium="1"
                     data-r-x-medium-nav="false"
                     data-r-x-medium-dots="true"
                     data-r-small="3"
                     data-r-small-nav="true"
                     data-r-small-dots="false"
                     data-r-medium="4"
                     data-r-medium-nav="true"
                     data-r-medium-dots="false">
                    <?php $__currentLoopData = $items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="special-dish-box">
                            <span>$<?php echo e($item->price); ?></span>
                            <a href="#"><img class="img-responsive" src="<?php echo e(url('uploads/item/'.$item->image)); ?>" alt="dish"></a>
                            <h3 class="title-small title-bar-small-center"><a href="#"><?php echo e($item->name); ?></a></h3>

                            <a href="#" class="ghost-semi-color-btn">Details</a>
                        </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            </div>
        </div>
    </div>
    <!-- Special Dish Area End Here -->
    <!-- Expert Chefs Area Start Here -->
    <div class="expert-chefs-area">
        <img class="img-responsive section-back" src="<?php echo e(asset('/')); ?>front-end/assets/img/team/section-back.png" alt="Sestion Back">
        <div class="container">
            <h2 class="title-color">Our Expert Chefs</h2>
            <span class="subtitle-color">Professional Cook Team</span>
            <div class="rc-carousel"
                 data-loop="true"
                 data-items="3"
                 data-margin="30"
                 data-autoplay="true"
                 data-autoplay-timeout="10000"
                 data-smart-speed="2000"
                 data-dots="false"
                 data-nav="true"
                 data-nav-speed="false"
                 data-r-x-small="2"
                 data-r-x-small-nav="false"
                 data-r-x-small-dots="true"
                 data-r-x-medium="2"
                 data-r-x-medium-nav="false"
                 data-r-x-medium-dots="true"
                 data-r-small="2"
                 data-r-small-nav="true"
                 data-r-small-dots="false"
                 data-r-medium="3"
                 data-r-medium-nav="true"
                 data-r-medium-dots="false">
                <?php $__currentLoopData = $chefs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $chef): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="expert-chefs-box">
                        <a href="#"><img class="img-responsive" src="<?php echo e(url('uploads/chefs/'.$chef->image)); ?>" alt="<?php echo e($chef->name); ?>"></a>
                        <div class="expert-chefs-box-content">
                            <span></span>
                            <h3><a href="#"><?php echo e($chef->name); ?></a></h3>
                            <p><?php echo e($chef->designation); ?></p>
                            <ul>
                                <li><a href="<?php echo e($chef->social_field_one); ?>"><i class="fa fa-facebook" aria-hidden="true"></i></a></li>
                                <li><a href="<?php echo e($chef->social_field_three); ?>"><i class="fa fa-twitter" aria-hidden="true"></i></a></li>
                                <li><a href="<?php echo e($chef->social_field_two); ?>"><i class="fa fa-linkedin" aria-hidden="true"></i></a></li>
                                <li><a href="<?php echo e($chef->social_field_four); ?>"><i class="fa fa-pinterest" aria-hidden="true"></i></a></li>
                            </ul>
                        </div>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

            </div>
        </div>
    </div>
    <!-- Expert Chefs Area End Here -->
    <!-- Brand Area Start Here -->
    <div class="brand-area">
        <img class="img-responsive section-back" src="<?php echo e(asset('/')); ?>front-end/assets/img/brand/back-logo.png" alt="back-logo">
        <div class="container">
            <div class="rc-carousel"
                 data-loop="true"
                 data-items="6"
                 data-margin="15"
                 data-autoplay="true"
                 data-autoplay-timeout="10000"
                 data-smart-speed="2000"
                 data-dots="false"
                 data-nav="true"
                 data-nav-speed="false"
                 data-r-x-small="2"
                 data-r-x-small-nav="false"
                 data-r-x-small-dots="true"
                 data-r-x-medium="3"
                 data-r-x-medium-nav="false"
                 data-r-x-medium-dots="true"
                 data-r-small="4"
                 data-r-small-nav="true"
                 data-r-small-dots="false"
                 data-r-medium="6"
                 data-r-medium-nav="true"
                 data-r-medium-dots="false">
                <?php $__currentLoopData = $sponsors; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sponsor): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="brand-area-box">
                        <a href="<?php echo e($sponsor->link); ?>"><img src="<?php echo e(url('uploads/brands/'.$sponsor->image)); ?>" alt="brand"></a>
                    </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </div>
    </div>
    <!-- Brand Area End Here -->
    <?php $__env->stopSection(); ?>
<?php echo $__env->make('front-end.layouts.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>