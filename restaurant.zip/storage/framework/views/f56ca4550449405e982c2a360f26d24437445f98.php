<?php
/**
 * Created by PhpStorm.
 * User: Kawshar
 * Date: 7/10/2018
 * Time: 11:07 AM
 */?>


<?php $__env->startSection('page_title'); ?>
    Chef Details
<?php $__env->stopSection(); ?>
<?php $__env->startSection('page_main_title'); ?>
    Chef
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="col-md-12">
            <div class="card-box">
                <table class="table ">
                    <tr>
                        <td>Name</td>
                        <td><?php echo e($chef->name); ?></td>
                    </tr>
                    <tr>
                        <td>Mobile Number</td>
                        <td><?php echo e($chef->phone_number); ?></td>
                    </tr>
                    <tr>
                        <td>Designation</td>
                        <td><?php echo e($chef->designation); ?></td>
                    </tr>
                    <tr>
                        <td>Description</td>
                        <td><?php echo e($chef->description); ?></td>
                    </tr>
                    <tr>
                        <td>Facebook link</td>
                        <td><?php echo e($chef->social_field_one); ?></td>
                    </tr>
                    <tr>
                        <td>Linkedin link </td>
                        <td><?php echo e($chef->social_field_two); ?></td>
                    </tr>
                    <tr>
                        <td>Twitter link </td>
                        <td><?php echo e($chef->social_field_three); ?></td>
                    </tr>
                    <tr>
                        <td>Instagram link </td>
                        <td><?php echo e($chef->social_field_four); ?></td>
                    </tr>

                    <tr>
                        <td>Image</td>
                        <td>
                            <img src="<?php echo e(url('uploads/chefs/'.$chef->image)); ?>" width="100px">
                        </td>
                    </tr>
                    <tr>
                        <td>Publication Status</td>
                        <td>
                            <?php if($chef->publication_status==1): ?>
                                Published
                            <?php else: ?>
                                unpublished
                            <?php endif; ?>

                        </td>
                    </tr>


                </table>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>



<?php echo $__env->make('admin.layouts.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>