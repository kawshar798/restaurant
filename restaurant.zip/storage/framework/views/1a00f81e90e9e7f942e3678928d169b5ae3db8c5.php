<?php
/**
 * Created by PhpStorm.
 * User: Kawshar
 * Date: 7/14/2018
 * Time: 3:58 PM
 */?>

<?php $__env->startSection('title'); ?>
    FOOD MENU
<?php $__env->stopSection(); ?>
<?php $__env->startSection('banner_title'); ?>
    Our Food menu
<?php $__env->stopSection(); ?>
<?php $__env->startSection('page_title'); ?>
    menu
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <?php echo $__env->make('front-end.layouts.includes.banner_area', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    <!-- Inner Page Banner Area End Here -->
    <!-- Food Menu 2 Area Start Here -->
    <div class="food-menu2-area">
        <div class="container" id="inner-isotope">
            <div class="row">
                <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                    <div class="isotop-classes-tab myisotop">
                        <a href="#" data-filter="*" class="current">All</a>

                        <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <a href="#" data-filter=".<?php echo e($category->slug); ?>"><?php echo e($category->name); ?>

                            <span class="badge"><?php echo e($category->item->count()); ?></span>
                            </a>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                    </div>
                </div>
            </div>
            <div class="row featuredContainer">
                <?php $__currentLoopData = $items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>


                <div class="col-lg-3 col-md-3 col-sm-4 col-xs-6 <?php echo e($item->category->slug); ?>" id="">
                    <div class="food-menu2-box">
                        <div class="food-menu2-img-holder">
                            <div class="food-menu2-more-holder">
                                <ul>
                                    <li><a href="#"><i class="fa fa-link" aria-hidden="true"></i></a></li>
                                </ul>
                            </div>
                            <a href="#"><img class="img-responsive" src="<?php echo e(asset('uploads/item/'.$item->image)); ?>" alt="dish"></a>
                        </div>
                        <div class="food-menu2-title-holder">
                            <span>$<?php echo e($item->price); ?></span>
                            <h3><a href="#"><?php echo e($item->name); ?></a></h3>
                        </div>
                    </div>
                </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


            </div>
        </div>
    </div>
    <?php $__env->stopSection(); ?>

<?php echo $__env->make('front-end.layouts.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>