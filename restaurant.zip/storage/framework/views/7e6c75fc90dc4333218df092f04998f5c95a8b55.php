<?php
/**
 * Created by PhpStorm.
 * User: Kawshar
 * Date: 7/13/2018
 * Time: 10:03 AM
 */?>
;
<?php $__env->startSection('page_title'); ?>
    Manage Contact
<?php $__env->stopSection(); ?>

<?php $__env->startSection('page_main_title'); ?>
    Contact
<?php $__env->stopSection(); ?>


<?php $__env->startSection('content'); ?>
    <!-- Example DataTables Card-->
    <div class="row">
        <div class="col-md-12">
            <div class="card-box">
                <div class="card">
                    <div class="card-header">
                    </div>
                    <div class="card-body">
                        <div class="table-responsive">
                            <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
                                <thead>
                                <tr>
                                    <th>No</th>
                                    <th>Name</th>
                                    <th>E-mail</th>
                                    <th>Subject</th>
                                    <th>Message</th>
                                    <th>Sent Time</th>
                                    <th>Action</th>

                                </tr>
                                </thead>
                                <tbody>

                                <?php $__currentLoopData = $contacts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$contact): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td><?php echo e($key + 1); ?></td>
                                        <td><?php echo e($contact->name); ?></td>
                                        <td><?php echo e($contact->email); ?></td>
                                        <td><?php echo e($contact->subject); ?></td>
                                        <td><?php echo e($contact->message); ?></td>
                                        <td><?php echo e($contact->created_at->diffForHumans()); ?></td>
                                        <td>
                                            <form action="<?php echo e(route('contact.delete',$contact->id)); ?>" method="post" id="formDelete-<?php echo e($contact->id); ?>" >
                                                <?php echo csrf_field(); ?>
                                                <?php echo method_field('DELETE'); ?>
                                            </form>
                                            <button type="button" class="btn btn-sm btn-danger" title="Delete" onclick="if (confirm('Are you sure delete this contact???')){

                                                    event.preventDefault();
                                                    document.getElementById('formDelete-<?php echo e($contact->id); ?>').submit();
                                                    } "><i class="fa fa-trash"></i> </button>

                                            <a  href="<?php echo e(route('contact.show',$contact->id)); ?>" class="btn btn-sm btn-info" title="Details"><i class="fa fa-info-circle"></i></a>
                                        </td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                </tbody>
                            </table>
                        </div>
                    </div>
                    <div class="card-footer small text-muted">Updated yesterday at 11:59 PM</div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>