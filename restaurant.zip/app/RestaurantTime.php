<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class RestaurantTime extends Model
{
    //
}
