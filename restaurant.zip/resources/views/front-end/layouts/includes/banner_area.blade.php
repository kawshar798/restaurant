<?php
/**
 * Created by PhpStorm.
 * User: Kawshar
 * Date: 7/14/2018
 * Time: 4:25 PM
 */?>
<div class="inner-page-banner-area">
    <div class="container">
        <div class="pagination-area">
            <h2>@yield('banner_title')</h2>
            <ul>
                <li><a href="/">Home -</a> /</li>
                <li>@yield('page_title')</li>
            </ul>
        </div>
    </div>
</div>
